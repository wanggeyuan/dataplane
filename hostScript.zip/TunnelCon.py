from scapy.all import *

def get_pop_IP():
    pop_IP = 'fd02::9'
    print(f"POP1的实际IP地址为{pop_IP}")
    return pop_IP

def get_iface():
    iface = '以太网 4'
    # print(f"接口为{iface}")
    return iface

def tunnel_packet(dest_ip):
    srcIP = "fd21::1"
    data = "Hello, this is from {} !".format(srcIP)
    dest_ip = "fd03::3"  # HOST2的实际IPv6地址地址
    pop_IP = 'fd21::2' # POP1的实际IP地址
    inner_packet = IPv6(src="fe02::2", dst=dest_ip) / UDP(sport=18888, dport=19999) / (f"{dest_ip}, {data}")
    packet = IPv6(src=srcIP, dst=pop_IP) / UDP(sport=18888, dport=80) / inner_packet
    return  packet