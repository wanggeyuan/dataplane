#host1
import time

from scapy.all import *
from TunnelCon import *

def main():
    srcIP = "fd02::2" # HOST1的实际IPv6地址
    # srcIP = "fd11::6" # HOST1的实际IPv6地址
    data = "Hello, this is from {} !".format(srcIP)
    dest_ip = "fd03::3"  # HOST2的实际IPv6地址地址
    pop_IP = get_pop_IP()  # POP1的实际IP地址
    inner_packet= IPv6(src=srcIP, dst=dest_ip) /  UDP(sport=18888, dport=20000) / (f"{dest_ip}, {data}")
    packet = IPv6(src=srcIP, dst=pop_IP) / UDP(sport=18888,dport=80) / inner_packet

    packet2=tunnel_packet(dest_ip)
    time.sleep(0.3)
    packet.show2()

    send(packet, iface='以太网 5', verbose=False)
    # if srcIP != "fd55::1":
    if srcIP != "fd11::6":
        send(packet2, iface=get_iface())
        pass
if __name__ == "__main__":
    while(True):
        time.sleep(0.7)
        main()

