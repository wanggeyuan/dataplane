from scapy.all import *
import time

# 定义B的IP地址
B_IP = "10.0.2.1"

def packet_callback(packet):
    # 检查是否是从A发送到C的TCP数据包
    if IP in packet and TCP in packet:
        outer_ip = packet[IP]
        outer_tcp = packet[TCP]

        # 检查目的IP是否是C
        if outer_ip.dst == "10.0.1.254":
            # 解封装内层数据包
            inner_packet = IP(packet[TCP].payload.load)

            # 打印内层数据包信息
            print(f"Received encapsulated packet from {outer_ip.src} to {outer_ip.dst}")
            print(f"Inner packet: {inner_packet.summary()}")

            # 修改内层数据包的源IP和目的IP
            inner_packet.src = outer_ip.src
            inner_packet.dst = B_IP

            # 发送内层数据包到B
            send(inner_packet)
            print(f"Forwarded inner packet to {inner_packet.dst}")

if __name__ == "__main__":
    # 开始嗅探网络接口，捕获数据包并调用回调函数处理
    print("Starting packet capture on interface eth0")
    sniff(iface="eth0", prn=packet_callback, filter="tcp", store=0)
