from scapy.all import *
import socket
import random
import time

A_IP = "10.0.1.1"
B_IP = "10.0.2.2"
C_IP = "10.0.1.9"

# 定义端口号
A_PORT = 12345
B_PORT = 80
C_PORT = 12345




def send_packet():
    # 创建一个IP数据包，从A到B
    inner_packet = IP(src=A_IP, dst=B_IP) / TCP(sport=A_PORT, dport=B_PORT) / "Hello, this is a test message from A to B"

    # 封装外层数据包，从A到C
    outer_packet = Ether(dst="cc:96:e5:38:5f:d3") / IP(src=A_IP, dst=C_IP) / TCP(sport=A_PORT, dport=C_PORT) / Raw(load=bytes(inner_packet))

    # 发送封装的数据包
    sendp(outer_packet)
    outer_packet.show2()

if __name__ == "__main__":
    # while True:
    send_packet()
    # time.sleep(random.uniform(1, 3))  # 随机延迟1到3秒
