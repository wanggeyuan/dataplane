import socket
 
# 创建一个UDP socket
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
 
# 定义目标IP和端口
dest_ip = '10.0.1.9'
dest_port = 22
 
# 要发送的数据
message = b'Hello, World!'
 
# 发送数据
udp_socket.sendto(message, (dest_ip, dest_port))
 
# 关闭socket
udp_socket.close()
