import random
import time
import random
from datetime import datetime


def print_with_delay(message, delay=random.uniform(0.5, 1.5)):
    print(message)
    time.sleep(delay)


def get_current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def main():
    print_with_delay(f"[INFO] {get_current_time()} - Initializing tunnel connection...")

    print_with_delay("Tunnel Connection Established")
    print_with_delay("Connected to POP node at 10.0.1.9", 0)

    print_with_delay(f"[INFO] {get_current_time()} - Tunnel Interface: 0")
    print_with_delay("Local IP: 10.0.1.9", 0)
    # print_with_delay("Remote IP: 10.0.1.254", 0)

    print_with_delay(f"[INFO] {get_current_time()} - Routing Table Updated")
    print_with_delay("Destination     Gateway         Mask         Flags  Metric  Ref    Use Iface", 0)
    print_with_delay("0.0.0.0         10.0.1.9        0.0.0.0      UG     600     0      0   以太网", 0)

    # print_with_delay(f"[INFO] {get_current_time()} - Sending packet to 10.0.2.1", 2)
    # print_with_delay("Encapsulating packet with header for 10.0.1.254", 2)
    # print_with_delay("Packet sent via overlay network", 2)
    #
    # print_with_delay(f"[INFO] {get_current_time()} - VPN Status: Connected", 2)
    # print_with_delay("Uptime: 00:05:23", 2)
    # print_with_delay("Bytes Sent: 1500", 2)
    # print_with_delay("Bytes Received: 2048", 2)
    #
    # print_with_delay(f"[INFO] {get_current_time()} - Log Information:", 2)
    # print_with_delay(f"[INFO] {get_current_time()} - VPN connection to 10.0.1.254 established.", 2)
    # print_with_delay(f"[INFO] {get_current_time()} - Packet destined for 10.0.2.1 encapsulated and sent to 10.0.1.254.", 2)
    # print_with_delay(f"[INFO] {get_current_time()} - Received response from 10.0.2.1 via 10.0.1.254.", 2)


if __name__ == "__main__":
    main()
